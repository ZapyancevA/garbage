import { CARD_BY_ID, ROWS, validateDeck } from './data.mjs';
export function shuffle(items, rng=Math.random){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function draw(p,n){for(let i=0;i<n&&p.deck.length;i++)p.hand.push(p.deck.pop());}
export function createGame(config,rng=Math.random){
 let serial=0;
 const players=config.map(({faction,deck})=>{if(validateDeck(faction,deck).length)throw Error('Invalid deck');return {faction,deck:shuffle(deck.map(id=>({uid:`c${serial++}`,id})),rng),hand:[],board:[],discard:[],wins:0,passed:false,energy:3,leaderUsed:false,signal:null};});
 if(players.length!==2)throw Error('Two players required');
 players.forEach(p=>draw(p,10));
 return {players,phase:'mulligan',turn:0,round:1,starter:0,weather:[],history:[],events:[],redraws:2,winner:null};
}
export function redraw(state,uid){
 if(state.phase!=='mulligan'||state.redraws<=0)throw Error('Cannot redraw');
 const p=state.players[0],i=p.hand.findIndex(c=>c.uid===uid);if(i<0||!p.deck.length)throw Error('Invalid redraw');
 const old=p.hand.splice(i,1)[0];draw(p,1);p.deck.unshift(old);state.redraws--;return state;
}
export function startGame(s){if(s.phase!=='mulligan')throw Error('Already started');s.phase='play';s.events=[{key:'battleStart'}];return s;}
export function strength(s,pi,unit){
 const c=CARD_BY_ID[unit.id];if(c.ability==='hero')return c.power;
 const p=s.players[pi];let value=Math.max(0,c.power+(unit.bonus||0)-(unit.damage||0));
 if(s.weather.includes(c.row))value=Math.min(value,2);
 value+=p.board.filter(u=>CARD_BY_ID[u.id].row===c.row&&CARD_BY_ID[u.id].ability==='relay'&&u.uid!==unit.uid).length;
 if(c.ability==='rally')value+=p.board.filter(u=>u.id===unit.id&&u.uid!==unit.uid).length*2;
 if(p.signal===c.row)value+=1;
 return value;
}
export function rowScore(s,pi,row){return s.players[pi].board.filter(u=>CARD_BY_ID[u.id].row===row).reduce((a,u)=>a+strength(s,pi,u),0);}
export function score(s,pi){return ROWS.reduce((a,r)=>a+rowScore(s,pi,r),0);}
function hit(s,pi,amount,all=false){
 const p=s.players[pi];const targets=p.board.filter(u=>CARD_BY_ID[u.id].ability!=='hero').sort((a,b)=>strength(s,pi,b)-strength(s,pi,a));
 for(const u of (all?targets:targets.slice(0,1))){if(u.shield){u.shield=false;}else u.damage=(u.damage||0)+amount;}
}
function finishRound(s){
 const totals=[score(s,0),score(s,1)];const win=totals[0]===totals[1]?null:totals[0]>totals[1]?0:1;
 if(win===null)s.players.forEach(p=>p.wins++);else s.players[win].wins++;
 s.history.push({round:s.round,scores:totals,winner:win});s.events.push({key:win===null?'roundDraw':'roundWin',player:win});
 if(s.players.some(p=>p.wins>=2)||s.round===3){s.phase='finished';s.winner=s.players[0].wins===s.players[1].wins?null:s.players[0].wins>s.players[1].wins?0:1;}
 else{s.phase='roundEnd';s.starter=win===null?1-s.starter:1-win;}
}
export function nextRound(s){
 if(s.phase!=='roundEnd')throw Error('Not between rounds');
 s.players.forEach(p=>{p.discard.push(...p.board);p.board=[];p.passed=false;p.energy=3;p.signal=null;draw(p,2);});
 s.weather=[];s.round++;s.turn=s.starter;s.phase='play';s.events=[{key:'newRound'}];return s;
}
export function legalActions(s,pi=s.turn){
 if(s.phase!=='play'||s.turn!==pi||s.players[pi].passed)return [];
 const p=s.players[pi];const actions=p.hand.map(c=>({type:'play',uid:c.uid}));
 if(p.energy>=2&&p.board.length)for(const row of ROWS)if(p.signal!==row&&p.board.some(c=>CARD_BY_ID[c.id].row===row))actions.push({type:'signal',row});
 if(!p.leaderUsed)actions.push({type:'leader'});
 actions.push({type:'pass'});return actions;
}
export function act(s,action){
 if(!legalActions(s).some(a=>JSON.stringify(a)===JSON.stringify(action)))throw Error('Illegal action');
 const pi=s.turn,p=s.players[pi],enemy=s.players[1-pi];s.events=[];
 if(action.type==='play'){
 const idx=p.hand.findIndex(c=>c.uid===action.uid),u=p.hand.splice(idx,1)[0],c=CARD_BY_ID[u.id];
 s.events.push({key:'played',player:pi,card:c.id});
 if(c.type==='unit'){
  u.damage=0;u.bonus=0;u.shield=c.ability==='guard';p.board.push(u);
  if(c.ability==='scout'){p.energy=Math.min(6,p.energy+1);}
  if(c.ability==='precision')hit(s,1-pi,2);
  if(c.ability==='disrupt'){enemy.energy=Math.max(0,enemy.energy-1);}
  if(c.ability==='repair'){
   const target=p.board.filter(v=>v.uid!==u.uid&&CARD_BY_ID[v.id].ability!=='hero').sort((a,b)=>(b.damage||0)-(a.damage||0))[0];
   if(target){target.damage=Math.max(0,(target.damage||0)-3);target.bonus=(target.bonus||0)+1;}
  }
 } else {
 p.discard.push(u);
 if(c.ability==='weather'&&!s.weather.includes(c.row))s.weather.push(c.row);
 if(c.ability==='clear')s.weather=[];
 if(c.ability==='strike')hit(s,1-pi,5);
 if(c.ability==='supply'){draw(p,1);p.energy=Math.min(6,p.energy+1);}
 }
 }else if(action.type==='signal'){p.energy-=2;p.signal=action.row;s.events.push({key:'signalUsed',player:pi});}
 else if(action.type==='leader'){
 p.leaderUsed=true;s.events.push({key:'leaderUsed',player:pi});
 switch(p.faction){
 case 'rebel': for(const u of p.board)if(CARD_BY_ID[u.id].ability!=='hero')u.bonus=(u.bonus||0)+1;break;
 case 'empire':hit(s,1-pi,2,true);break;
 case 'republic':for(const u of p.board)if(CARD_BY_ID[u.id].ability!=='hero'){u.shield=true;u.damage=0;}break;
 case 'separatist':draw(p,2);p.energy=Math.max(0,p.energy-2);break;
 case 'syndicate':draw(p,1);p.energy=Math.min(6,p.energy+2);break;
 }
 }else{p.passed=true;s.events.push({key:'passed',player:pi});}
 if(p.passed&&enemy.passed)finishRound(s);else s.turn=enemy.passed?pi:1-pi;
 return s;
}
export function chooseBotAction(s, difficulty='normal',rng=Math.random){
 const pi=s.turn,p=s.players[pi],enemy=s.players[1-pi];const actions=legalActions(s,pi);if(!actions.length)return null;
 const gap=score(s,pi)-score(s,1-pi);
 if(enemy.passed&&gap>0)return {type:'pass'};
 if(!p.hand.length&&!p.board.length)return {type:'pass'};
 if(difficulty==='easy'){const cards=actions.filter(a=>a.type==='play');return cards.length?cards[Math.floor(rng()*cards.length)]:{type:'pass'};}
 // Information boundary: evaluation uses public board and this player's hand only.
 if(!enemy.passed&&s.round<3&&p.hand.length<=5&&gap < -18&&p.wins===0)return {type:'pass'};
 if(!enemy.passed&&s.round<3&&gap>20&&p.hand.length<enemy.hand.length)return {type:'pass'};
 let best=null,bestValue=-Infinity;
 for(const action of actions.filter(a=>a.type!=='pass')){
 const sim=structuredClone(s);act(sim,action);let value=(score(sim,pi)-score(sim,1-pi))-gap;
 value+=(sim.players[pi].hand.length-p.hand.length)*4;
 value+=(sim.players[pi].energy-p.energy)*0.65;
 value+=sim.players[pi].board.filter(u=>u.shield).length*0.25-p.board.filter(u=>u.shield).length*0.25;
 if(action.type==='play'){
 const c=CARD_BY_ID[p.hand.find(u=>u.uid===action.uid).id];
 if(c.ability==='relay')value+=1.5;
 if(c.ability==='rally')value+=p.hand.filter(u=>u.id===c.id).length;
 if(c.ability==='hero'&&s.round===1)value-=2;
 }
 if(action.type==='leader')value-=3;
 if(enemy.passed&&score(sim,pi)>score(sim,1-pi))value+=30-Math.max(0,score(sim,pi)-score(sim,1-pi))*0.7;
 value+=rng()*0.3;
 if(value>bestValue){best=action;bestValue=value;}
 }
 return best||{type:'pass'};
}
