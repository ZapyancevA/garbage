export const ROWS = ['ground', 'fleet', 'support'];
export const FACTIONS = [
  { id: 'rebel', ru: 'Альянс повстанцев', en: 'Rebel Alliance', color: '#ef9363', emblem: '✦', leader: { ru: 'Лея Органа', en: 'Leia Organa' }, doctrine: {ru:'Слаженность', en:'Coordination'} },
  { id: 'empire', ru: 'Галактическая Империя', en: 'Galactic Empire', color: '#89aacf', emblem: '⬡', leader: { ru: 'Дарт Вейдер', en: 'Darth Vader' }, doctrine: {ru:'Превосходство', en:'Supremacy'} },
  { id: 'republic', ru: 'Галактическая Республика', en: 'Galactic Republic', color: '#d49b9b', emblem: '✺', leader: { ru: 'Оби-Ван Кеноби', en: 'Obi-Wan Kenobi' }, doctrine: {ru:'Защитный строй', en:'Defensive formation'} },
  { id: 'separatist', ru: 'Конфедерация систем', en: 'Confederacy of Systems', color: '#91c5bb', emblem: '❖', leader: { ru: 'Граф Дуку', en: 'Count Dooku' }, doctrine: {ru:'Массовое производство', en:'Mass production'} },
  { id: 'syndicate', ru: 'Внешнее Кольцо', en: 'Outer Rim', color: '#d7bb70', emblem: '◈', leader: { ru: 'Хаттский совет', en: 'Hutt Council' }, doctrine: {ru:'Выгодная сделка', en:'Good business'} }
];
// Original fan-made card roster. No extracted game assets or copied card database.
const rosters = {
 rebel: [ ['Люк Скайуокер','Luke Skywalker','ground',9,'hero'], ['Хан Соло','Han Solo','ground',6,'precision'], ['Чубакка','Chewbacca','ground',7,'guard'], ['Разведчики Эндора','Endor scouts','ground',3,'scout'], ['Пехота Альянса','Alliance infantry','ground',4,'rally'], ['Десантники','Pathfinders','ground',5,'plain'], ['Красная эскадрилья','Red Squadron','fleet',6,'rally'], ['Звено A-wing','A-wing flight','fleet',4,'scout'], ['Мон-каламарский крейсер','Mon Calamari cruiser','fleet',8,'guard'], ['Звено Y-wing','Y-wing flight','fleet',5,'precision'], ['R2-D2','R2-D2','support',3,'repair'], ['Центр связи','Comms outpost','support',4,'relay'], ['База на Явине','Yavin base','support',6,'guard'], ['Ботанские связные','Bothan contacts','support',2,'scout'] ],
 empire: [ ['Дарт Вейдер','Darth Vader','ground',9,'hero'], ['Штурмовой отряд','Stormtrooper squad','ground',4,'rally'], ['Смертельные солдаты','Death troopers','ground',6,'precision'], ['AT-ST','AT-ST','ground',6,'guard'], ['Имперский зонд','Imperial probe','ground',2,'scout'], ['Снежный десант','Snowtroopers','ground',5,'plain'], ['Звено TIE','TIE flight','fleet',4,'rally'], ['TIE-перехватчики','TIE interceptors','fleet',5,'precision'], ['Звёздный разрушитель','Star Destroyer','fleet',8,'guard'], ['Разведывательный шаттл','Recon shuttle','fleet',3,'scout'], ['Имперский офицер','Imperial officer','support',4,'relay'], ['Ремонтный док','Repair dock','support',3,'repair'], ['Орбитальная станция','Orbital station','support',7,'plain'], ['Служба разведки','Intelligence bureau','support',3,'disrupt'] ],
 republic: [ ['Оби-Ван Кеноби','Obi-Wan Kenobi','ground',9,'hero'], ['Капитан Рекс','Captain Rex','ground',6,'relay'], ['Бойцы 501-го','501st troopers','ground',4,'rally'], ['Клоны-коммандос','Clone commandos','ground',5,'precision'], ['Разведчики ARF','ARF scouts','ground',3,'scout'], ['AT-TE','AT-TE','ground',7,'guard'], ['Звено ARC-170','ARC-170 flight','fleet',5,'rally'], ['Перехватчик джедая','Jedi interceptor','fleet',6,'precision'], ['Венатор','Venator','fleet',8,'guard'], ['Шаттл снабжения','Supply shuttle','fleet',3,'repair'], ['Полевые медики','Field medics','support',3,'repair'], ['Командный пост','Command post','support',4,'relay'], ['Связисты','Signal team','support',2,'scout'], ['Артиллерийская батарея','Artillery battery','support',6,'plain'] ],
 separatist: [ ['Генерал Гривус','General Grievous','ground',9,'hero'], ['Боевые дроиды B1','B1 battle droids','ground',3,'rally'], ['Супердроиды B2','B2 super battle droids','ground',5,'rally'], ['Дроидека','Droideka','ground',6,'guard'], ['Дроиды-коммандос','Commando droids','ground',5,'precision'], ['Дроид-разведчик','Recon droid','ground',2,'scout'], ['Дроиды-стервятники','Vulture droids','fleet',4,'rally'], ['Гиена-бомбардировщик','Hyena bomber','fleet',5,'precision'], ['Крейсер Провидение','Providence cruiser','fleet',8,'guard'], ['Сторожевой корабль','Picket ship','fleet',3,'disrupt'], ['Тактический дроид','Tactical droid','support',4,'relay'], ['Сборочная линия','Assembly line','support',3,'repair'], ['Ретранслятор','Signal repeater','support',2,'scout'], ['Осадная установка','Siege platform','support',7,'plain'] ],
 syndicate: [ ['Боба Фетт','Boba Fett','ground',9,'hero'], ['Кэд Бэйн','Cad Bane','ground',6,'precision'], ['Мандалорские наёмники','Mandalorian mercenaries','ground',5,'guard'], ['Наёмники Кольца','Rim mercenaries','ground',4,'rally'], ['Следопыт','Tracker','ground',3,'scout'], ['Охотник за головами','Bounty hunter','ground',5,'disrupt'], ['Пиратское звено','Pirate flight','fleet',4,'rally'], ['Патрульный Firespray','Firespray patrol','fleet',6,'precision'], ['Вооружённый фрахтовик','Armed freighter','fleet',7,'guard'], ['Корабль контрабандистов','Smuggling ship','fleet',3,'scout'], ['Подпольная мастерская','Hidden workshop','support',3,'repair'], ['Посредник','Broker','support',4,'relay'], ['Теневая сеть','Shadow network','support',2,'scout'], ['База на астероиде','Asteroid base','support',6,'guard'] ]
};
export const CARDS = [];
for (const faction of FACTIONS) rosters[faction.id].forEach(([ru,en,row,power,ability],i) => CARDS.push({ id:`${faction.id}-${i}`, faction:faction.id, name:{ru,en}, row, power, ability, type:'unit', max:ability==='hero'?1:2 }));
const tactics = [
 ['ion','Ионный фронт','Ion front','fleet','weather'],
 ['dust','Пылевая завеса','Dust veil','ground','weather'],
 ['jam','Помехи связи','Signal interference','support','weather'],
 ['clear','Чистые частоты','Clear frequencies',null,'clear'],
 ['strike','Точный удар','Precision strike',null,'strike'],
 ['supply','Резерв снабжения','Supply reserve',null,'supply']
];
tactics.forEach(([id,ru,en,row,ability])=>CARDS.push({id,faction:'neutral',name:{ru,en},row,power:0,ability,type:'tactic',max:2}));
export const CARD_BY_ID = Object.fromEntries(CARDS.map(c=>[c.id,c]));
export function availableCards(faction) { return CARDS.filter(c=>c.faction===faction||c.faction==='neutral'); }
export function starterDeck(faction) {
 const units=CARDS.filter(c=>c.faction===faction);
 return [...units.flatMap(c=>Array(c.max).fill(c.id)), 'clear','strike','supply'];
}
export function validateDeck(faction, ids) {
 const errors=[]; const counts={};
 if(!FACTIONS.some(f=>f.id===faction)) errors.push('faction');
 if(!Array.isArray(ids)) return ['invalid'];
 for(const id of ids){const c=CARD_BY_ID[id]; if(!c||(c.faction!==faction&&c.faction!=='neutral')){errors.push('foreign');continue;}counts[id]=(counts[id]||0)+1;if(counts[id]>c.max)errors.push('copies');}
 if(ids.length<24||ids.length>34)errors.push('size');
 if(ids.filter(id=>CARD_BY_ID[id]?.type==='unit').length<22)errors.push('units');
 return [...new Set(errors)];
}
