export class AudioEngine {
 constructor(){this.ctx=null;this.master=null;this.ambient=null;this.nodes=[];this.settings={audio:true,music:false,volume:35};}
 init(){if(!this.ctx){const C=globalThis.AudioContext||globalThis.webkitAudioContext;if(!C)return;this.ctx=new C();this.master=this.ctx.createGain();this.master.connect(this.ctx.destination);}this.ctx.resume().catch(()=>{});this.update(this.settings);}
 update(settings){this.settings={...settings};if(!this.ctx)return;this.master.gain.setTargetAtTime(settings.volume/100*0.25,this.ctx.currentTime,0.1);if(settings.music&&!this.ambient)this.startAmbient();if(!settings.music&&this.ambient)this.stopAmbient();}
 tone(freq,duration,type='sine',delay=0,level=0.25){if(!this.ctx)return;const t=this.ctx.currentTime+delay,o=this.ctx.createOscillator(),g=this.ctx.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(level,t+0.015);g.gain.exponentialRampToValueAtTime(0.001,t+duration);o.connect(g);g.connect(this.master);o.start(t);o.stop(t+duration+0.05);}
 play(name){if(!this.settings.audio)return;this.init();if(name==='deploy'){this.tone(180,.14,'triangle');this.tone(360,.25,'sine',.06);}else if(name==='win'){[220,277.18,329.63,440].forEach((n,i)=>this.tone(n,.8,'sine',i*.12));}else if(name==='pass'){this.tone(160,.35);this.tone(110,.4,'sine',.1);}else this.tone(480,.07,'sine',0,.1);}
 startAmbient(){this.ambient=this.ctx.createGain();this.ambient.gain.value=.12;this.ambient.connect(this.master);for(const freq of [55,82.4069,110.17,164.81]){const o=this.ctx.createOscillator();o.type='sine';o.frequency.value=freq;o.connect(this.ambient);o.start();this.nodes.push(o);}}
 stopAmbient(){this.nodes.forEach(n=>n.stop());this.nodes=[];this.ambient.disconnect();this.ambient=null;}
}
