import {test,expect} from '@playwright/test';
const action=(p,a)=>p.locator(`[data-action="${a}"]`);
test('menus, localization, deck persistence, audio and desktop/mobile layout',async({page})=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/');await expect(action(page,'start')).toBeVisible();
 await page.screenshot({path:'screenshots/home-desktop.png',fullPage:true});
 await action(page,'language').click();await expect(action(page,'start')).toHaveText(/Launch operation/);
 await action(page,'settings').click();await page.locator('#setting-music').check();await page.locator('#setting-volume').fill('15');await page.locator('#setting-audio').uncheck();await action(page,'close').click();
 await action(page,'edit-current').click();await expect(page.locator('.collection-item')).toHaveCount(20);
 await page.locator('.collection-item').filter({has:page.locator('[data-card="rebel-1"]')}).locator('[data-action="remove"]').click();
 await action(page,'save-deck').click();await page.reload();await action(page,'edit-current').click();await expect(page.locator('.sidebar-heading>strong')).toContainText('29');
 await page.locator('#search').fill('Luke');await expect(page.locator('.collection-item')).toHaveCount(1);
 await page.locator('.collection-item .card').click();await expect(page.locator('.card-detail h2')).toHaveText('Luke Skywalker');await action(page,'close').click();
 await page.locator('.page-heading [data-action="home"]').click();
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'screenshots/home-mobile.png',fullPage:true});
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 await action(page,'rules').click();await expect(page.locator('.rules-grid article')).toHaveCount(5);await action(page,'close').click();
 expect(errors).toEqual([]);
});
test('play an entire match against the bot and inspect battlefield',async({page})=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/');await action(page,'start').click();await expect(page.locator('.mulligan-grid .card')).toHaveCount(10);
 await action(page,'redraw').first().click();await expect(page.locator('.mulligan-count b')).toHaveText('1');await action(page,'begin').click();
 await page.locator('.hand-cards .card').first().click();await action(page,'selected-details').click();await expect(page.locator('.card-detail')).toBeVisible();await action(page,'deploy-modal').click();
 await expect(action(page,'pass')).toBeEnabled({timeout:5000});
 await page.screenshot({path:'screenshots/battle-desktop.png',fullPage:true});
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'screenshots/battle-mobile.png',fullPage:true});
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 await page.setViewportSize({width:1440,height:1000});
 await page.locator('.board-card').first().click();await expect(page.locator('.card-detail')).toBeVisible();await action(page,'close').click();
 for(let round=0;round<3;round++){
  if(await action(page,'rematch').count())break;
  if(await action(page,'next-round').count())await action(page,'next-round').click();
  await expect(action(page,'pass')).toBeEnabled({timeout:10000});await action(page,'pass').click();
  await expect(page.locator('.result')).toBeVisible({timeout:40000});
 }
 await expect(action(page,'rematch')).toBeVisible();await page.screenshot({path:'screenshots/result.png'});
 await action(page,'leave-result').click();await expect(action(page,'start')).toBeVisible();expect(errors).toEqual([]);
});
