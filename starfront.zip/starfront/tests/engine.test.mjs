import test from 'node:test';
import assert from 'node:assert/strict';
import {FACTIONS,CARDS,CARD_BY_ID,starterDeck,validateDeck} from '../src/data.mjs';
import {createGame,startGame,redraw,act,nextRound,strength,score,legalActions,chooseBotAction} from '../src/engine.mjs';
import {TEXT} from '../src/i18n.mjs';
function rng(seed=42){return ()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};}
function game(a='rebel',b='empire'){return startGame(createGame([{faction:a,deck:starterDeck(a)},{faction:b,deck:starterDeck(b)}],rng()));}
function unit(id,uid=id){return {id,uid,damage:0,bonus:0,shield:false};}
function setHand(s,pi,ids){s.players[pi].hand=ids.map((id,i)=>unit(id,`test-${pi}-${i}`));}
function play(s){return act(s,{type:'play',uid:s.players[s.turn].hand[0].uid});}
test('all five starter decks are legal and card ids are unique',()=>{
 assert.equal(new Set(CARDS.map(c=>c.id)).size,CARDS.length);
 for(const f of FACTIONS){assert.deepEqual(validateDeck(f.id,starterDeck(f.id)),[]);assert.equal(starterDeck(f.id).length,30);}
});
test('deck validation catches missing, foreign, excessive and insufficient units',()=>{
 assert.deepEqual(validateDeck('rebel',undefined),['invalid']);
 assert.ok(validateDeck('rebel',[]).includes('size'));
 assert.ok(validateDeck('rebel',[...starterDeck('rebel'),'empire-0']).includes('foreign'));
 assert.ok(validateDeck('rebel',[...starterDeck('rebel'),'rebel-0']).includes('copies'));
 assert.ok(validateDeck('rebel',Array(24).fill('strike')).includes('units'));
});
test('both languages cover the same translation keys',()=>assert.deepEqual(Object.keys(TEXT.ru).sort(),Object.keys(TEXT.en).sort()));
test('initial hand, unique instances and mulligan conservation',()=>{
 const s=createGame([{faction:'rebel',deck:starterDeck('rebel')},{faction:'empire',deck:starterDeck('empire')}],rng());
 assert.equal(s.players[0].hand.length,10);assert.equal(s.players[0].deck.length,20);
 const ids=s.players.flatMap(p=>[...p.hand,...p.deck].map(u=>u.uid));assert.equal(new Set(ids).size,60);
 const old=s.players[0].hand[0].uid;redraw(s,old);assert.equal(s.players[0].hand.length,10);assert.ok(!s.players[0].hand.some(u=>u.uid===old));
 redraw(s,s.players[0].hand[0].uid);assert.throws(()=>redraw(s,s.players[0].hand[0].uid));
 startGame(s);assert.throws(()=>redraw(s,s.players[0].hand[0].uid));
});
test('a passed player never receives the turn again in the same round',()=>{
 const s=game();act(s,{type:'pass'});assert.equal(s.turn,1);play(s);assert.equal(s.turn,1);play(s);assert.equal(s.turn,1);act(s,{type:'pass'});assert.equal(s.phase,'roundEnd');assert.equal(s.players[1].wins,1);
});
test('tied rounds grant both sides a win and two ties end in a draw',()=>{
 const s=game();act(s,{type:'pass'});act(s,{type:'pass'});assert.equal(s.phase,'roundEnd');nextRound(s);act(s,{type:'pass'});act(s,{type:'pass'});assert.equal(s.phase,'finished');assert.equal(s.winner,null);
});
test('round reset discards board, draws two, restores energy, keeps leader usage',()=>{
 const s=game();setHand(s,0,['rebel-5']);play(s);act(s,{type:'pass'});act(s,{type:'leader'});act(s,{type:'pass'});assert.equal(s.phase,'roundEnd');const deckSize=s.players[0].deck.length;
 nextRound(s);assert.equal(s.players[0].board.length,0);assert.equal(s.players[0].discard.length,1);assert.equal(s.players[0].deck.length,deckSize-2);assert.equal(s.players[0].energy,3);assert.equal(s.players[0].leaderUsed,true);assert.equal(s.turn,1);
});
test('heroes ignore damage, weather, rally, relay and orders',()=>{
 const s=game(),u=unit('rebel-0');u.damage=30;u.bonus=20;s.players[0].board=[u,unit('rebel-11')];s.weather=['ground'];s.players[0].signal='ground';assert.equal(strength(s,0,u),9);
});
test('weather caps base strength before wing and order bonuses',()=>{
 const s=game(),u=unit('rebel-4','a');s.players[0].board=[u,unit('rebel-4','b')];s.weather=['ground'];s.players[0].signal='ground';assert.equal(strength(s,0,u),5);
});
test('shields absorb one whole hit; next strike deals damage',()=>{
 const s=game();const target=unit('empire-3');target.shield=true;s.players[1].board=[target];setHand(s,0,['strike','strike']);s.players[1].passed=true;
 play(s);assert.equal(target.shield,false);assert.equal(target.damage,0);play(s);assert.equal(target.damage,5);assert.equal(strength(s,1,target),1);
});
test('repair chooses the most damaged unit and excludes heroes',()=>{
 const s=game(),a=unit('rebel-5'),b=unit('rebel-1');a.damage=4;b.damage=2;s.players[0].board=[a,b];setHand(s,0,['rebel-10']);play(s);assert.equal(a.damage,1);assert.equal(a.bonus,1);assert.equal(b.damage,2);
});
test('orders cost two energy, replace previous row and use the turn',()=>{
 const s=game();s.players[0].board=[unit('rebel-5'),unit('rebel-6')];act(s,{type:'signal',row:'ground'});assert.equal(s.players[0].energy,1);assert.equal(s.turn,1);assert.equal(s.players[0].signal,'ground');assert.equal(score(s,0),12);
 s.turn=0;assert.throws(()=>act(s,{type:'signal',row:'fleet'}));s.players[0].energy=3;act(s,{type:'signal',row:'fleet'});assert.equal(s.players[0].signal,'fleet');
});
test('clear removes all interference, recon energy is capped',()=>{
 const s=game();s.weather=['ground','fleet','support'];setHand(s,0,['clear','rebel-3']);s.players[1].passed=true;play(s);assert.deepEqual(s.weather,[]);s.players[0].energy=6;play(s);assert.equal(s.players[0].energy,6);
});
test('leader can only be used once per match and each faction resolves',()=>{
 for(const f of FACTIONS){const s=game(f.id,'empire');s.players[0].board=[unit(`${f.id}-1`)];s.players[1].board=[unit('empire-1')];act(s,{type:'leader'});assert.equal(s.players[0].leaderUsed,true);s.turn=0;assert.throws(()=>act(s,{type:'leader'}));}
});
test('bot passes after opponent passes when already ahead',()=>{
 const s=game();s.turn=1;s.players[0].passed=true;s.players[1].board=[unit('empire-0')];assert.deepEqual(chooseBotAction(s),{type:'pass'});
});
test('bot choice does not depend on hidden opponent card values',()=>{
 const s=game();s.turn=1;const changed=structuredClone(s);changed.players[0].hand=changed.players[0].hand.map((u,i)=>({...u,id:i%2?'rebel-0':'clear'}));changed.players[0].deck.reverse();assert.deepEqual(chooseBotAction(s,'normal',rng(9)),chooseBotAction(changed,'normal',rng(9)));
});
test('100 full bot matches terminate with legal actions and conserved cards',()=>{
 for(let seed=1;seed<=100;seed++){
 const random=rng(seed),a=FACTIONS[seed%5].id,b=FACTIONS[(seed+2)%5].id;
 const s=startGame(createGame([{faction:a,deck:starterDeck(a)},{faction:b,deck:starterDeck(b)}],random));let steps=0;
 while(s.phase!=='finished'&&steps++<250){if(s.phase==='roundEnd'){nextRound(s);continue;}const action=chooseBotAction(s,'normal',random);assert.ok(action);assert.ok(legalActions(s).some(a=>JSON.stringify(a)===JSON.stringify(action)));act(s,action);for(const [pi,p]of s.players.entries()){assert.ok(p.energy>=0&&p.energy<=6);assert.ok(score(s,pi)>=0);const cards=[...p.deck,...p.hand,...p.board,...p.discard];assert.equal(cards.length,30);assert.equal(new Set(cards.map(u=>u.uid)).size,30);}}
 assert.equal(s.phase,'finished',`seed ${seed} stalled`);assert.ok(s.players.some(p=>p.wins>=2));
 }
});
