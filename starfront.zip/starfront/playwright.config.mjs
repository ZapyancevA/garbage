import {defineConfig} from '@playwright/test';
export default defineConfig({
 testDir:'./tests',testMatch:'ui.spec.mjs',fullyParallel:false,workers:1,timeout:60000,
 use:{baseURL:'http://127.0.0.1:4173',viewport:{width:1440,height:1000},launchOptions:{channel:'chrome'},screenshot:'only-on-failure'},
 webServer:{command:'node server.mjs',url:'http://127.0.0.1:4173',reuseExistingServer:true},
 reporter:'list'
});
